# Cognigy Okta Extension

Provides a node to retrieve an access token using Okta's Client Credentials Grant.